import { Circle } from "./Circle.js";

const c1 = new Circle(10);
c1.draw();

console.log("test of webpack watching");
