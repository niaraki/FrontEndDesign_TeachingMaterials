export class Circle {
  constructor(radius) {
    this.radius = radius;
  }
  draw() {
    console.log("Draw circle with radius", this.radius);
  }
}
